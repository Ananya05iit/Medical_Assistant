import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import "../styles/tailwind.css";
import { useAuth } from '../authContext';

const Signup = () => {
  const {register} = useAuth();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
    console.log(formData)
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    alert('User registered successfully!');
  
    try {
      // Create user with Firebase
      // const userCredential = await createUserWithEmailAndPassword(auth, formData.email, formData.password);
      // const user = userCredential.user;
      register(formData.email, formData.password, formData.name).then((user)=>{
        setIsLoading(false);
        navigate('/');
        alert('User registered successfully!');
      })
      .catch((err)=>{console.log(err); setIsLoading(false)})
      // // Store additional user information in Firestore
      // await firestore.collection('users').doc(user.uid).set({
      //   name: formData.name,
      //   email: formData.email,
      //   phoneNumber: formData.phoneNumber,
      // });
  
      // Alert and redirect after successful registration
    } catch (error) {
      console.error('Signup failed:', error.message);
      // Set loading to false in case of an error
      setIsLoading(false);
    }
  };

  return (
    <div>
      <div className="flex items-center justify-center my-20">
  <div className="w-full max-w-md p-6 bg-gray-100 bg-opacity-75 rounded shadow-md">
    <div className="text-center mb-4">
      <h2 className="text-2xl font-bold">Register your Account</h2>
    </div>
    <form onSubmit={handleSubmit}>
      <div className="mb-4">
        <input
          type="text"
          id="name"
          name="name"
          required
          value={formData.name}
          onChange={handleChange}
          className="w-full p-2 border border-gray-300 rounded"
          placeholder="Name"
        />
      </div>
      <div className="mb-4">
        <input
          type="email"
          id="email"
          name="email"
          required
          value={formData.email}
          onChange={handleChange}
          className="w-full p-2 border border-gray-300 rounded"
          placeholder="Email"
        />
      </div>
      <div className="mb-4">
        <input
          type="password"
          id="password"
          name="password"
          required
          value={formData.password}
          onChange={handleChange}
          className="w-full p-2 border border-gray-300 rounded"
          placeholder="Password"
        />
      </div>
      <button type="submit" className="bg-color text-white px-4 py-2 rounded w-full">
        Signup
      </button>
    </form>
    <div className="mt-4 text-center">
      Already have an account? <NavLink to='/login' className="text-blue-500">Login</NavLink>
    </div>
  </div>
</div>

    </div>
  );
};

export default Signup;
