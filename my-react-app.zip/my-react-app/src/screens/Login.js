import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import '../styles/tailwind.css';
import { useAuth } from '../authContext';
const Login = () => {
    
    const [formData, setFormData] = useState({
        email: '',
        password: '',
      });
      const {login} = useAuth();
    const navigate = useNavigate();
    const [isLoading, setIsLoading] = useState(false);

    const handleChange = (e) => {
        setFormData({
          ...formData,
          [e.target.name]: e.target.value,
        });
      };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsLoading(true);
    
        try {
          // Sign in with Firebase
          // await auth.signInWithEmailAndPassword(formData.email, formData.password);
          login(formData.email,formData.password).then((user)=>{
            setIsLoading(false);
            navigate('/');
            alert('User Logged In successfully!');
          })
          .catch((error)=>{
            console.error('Signin failed:', error.message);
            setIsLoading(false);
          })
          // Redirect to the home page after successful sign-in
        } catch (error) {
          console.error('Signin failed:', error.message);
          // Set loading to false in case of an error
        }
      };
    // const login=
    //     useGoogleLogin({
    //         onSuccess: (response) => console.log(response.data),
    //         onFailure: (response) => console.log(response)
    //     })
    
    return (
        <div className="flex items-center justify-center h-screen">
            <div className="w-full max-w-md p-6 bg-gray-100 rounded shadow-md">
                <div className="text-center mb-4">
                    <h2 className="text-2xl font-bold">Login to your Account</h2>
                </div>
                <h2 className="text-xl mb-4">LOGIN</h2>
                <form onSubmit={handleSubmit}>
                    <div className="mb-4">
                        <input
                            type="email"
                            name="email"
                            id="email"
                            required
                            className="w-full p-2 border border-gray-300 rounded"
                            placeholder="Email"
                            value={formData.email}
                            onChange={handleChange}
                        />
                    </div>
                    <div className="mb-4">
                        <input
                            type="password"
                            name="password"
                            id="password"
                            required
                            className="w-full p-2 border border-gray-300 rounded"
                            placeholder="Password"
                            value={formData.password}
                            onChange={handleChange}
                        />
                    </div>
                    <NavLink to="/forgot-password" className="text-blue-500 block mb-4">Forgot password?</NavLink>
                    <button
                        type="submit"
                        className="bg-color text-white px-4 py-2 rounded w-full"
                    >
                        Log In
                    </button>
                </form>
                <div className="mt-4 text-center">
                    Don't have an account?
                    <NavLink to='/signup' className="text-blue-500"> Signup</NavLink>
                </div>
            </div>
        </div>
    );
}

export default Login;
