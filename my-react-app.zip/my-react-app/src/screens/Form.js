import { Input, Option, Select } from "@material-tailwind/react";
import axios from "axios";
import React, { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../authContext";
import "../styles/tailwind.css";
const Form = () => {
  const backendUrl = process.env.REACT_APP_BASE_URL;
  const [commentDiv, setCommentDiv] = useState(false);
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const { filled } = location.state || {};
  // console.log("state:", filled)
  // if(filled.comments){
  //   // alert(`Your application has been ${filled.status}. Comments: ${filled.comments}`)
  //   setCommentDiv(true)
  //   console.log("Comments:", filled.comments)
  // }
  // console.log(currentUser);
  const [formData, setFormData] = useState({
    patientName: "",
    gender: "",
    age: "",
    address: "",
    contactNumber: "",
    email: "",
    doctorSpeaciality: "",
    doctorName: "",
    hospital: "",
    //doctorEmail: "",
    appointmentDate: "",
    appointmentTime: "",
    expectedWaitingTime: "",
    termsAccepted: false,
  });
  const [file1Data, setFile1Data] = useState(null);
  const file1Ref = useRef(null);
  const [file2Data, setFile2Data] = useState(null);
  const file2Ref = useRef(null);
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
    // console.log(e.target.name, e.target.value);
  };
  const handleFileChange = (e, i) => {
    if (e.target.files[0].type !== "application/pdf") {
      alert("Please upload a PDF file");
      if (i === 1) file1Ref.current.value = "";
      else file2Ref.current.value = "";
      return;
    }
    if (i === 1) setFile1Data(e.target.files[0]);
    else setFile2Data(e.target.files[0]);

    // console.log(e.target.files[0])
  };

  const handleCheckboxChange = () => {
    setFormData({
      ...formData,
      termsAccepted: !formData.termsAccepted,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.termsAccepted) {
      alert("Please accept the terms and conditions");
      return;
    }
    // console.log("Form submitted:", formData);
    
    const data = new FormData();
    data.append("patientName", formData.patientName);
    data.append("gender", formData.gender);
    data.append("age", formData.age);
    data.append("address", formData.address);
    data.append("contactNumber", formData.contactNumber);
    data.append("email", formData.email);
    data.append("doctorSpeaciality", formData.doctorSpeaciality);
    data.append("doctorName", formData.doctorName);
    data.append("hospital", formData.hospital);
    //data.append("facultyEmail", formData.doctorEmail);
    data.append("appointmentDate", formData.appointmentDate);
    data.append("appointmentTime", formData.appointmentTime);
    data.append("expectedWaitingTime", formData.expectedWaitingTime);
    data.append("citizenshipProof", file1Data);
    //data.append("instituteLetter", file2Data);
    
    if (filled) {
      data.append("correction", filled.application_id);
    }
    axios
      .post(
        `${backendUrl}/api/booking`,
        data,
        { withCredentials: true },
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      )
      .then((res) => {
        console.log(res);
        alert("Form Submitted Successfully");
        navigate("/home");
      })
      .catch((err) => {
        console.log(err);
      });
  };
  useEffect(() => {
    if (currentUser) {
      setFormData((prevFormData) => ({
        ...prevFormData,
        patientNameName: currentUser.name,
        email: currentUser.email,
        // Update other fields accordingly
      }));
    }
    if (filled && filled.comments) {
      setCommentDiv(true);
      console.log("Comments:", filled.comments);
    }
  }, [currentUser, filled]);
  return (
    <div className="bg-white px-4 -mt-6 pt-6">
      <h1 className="text-2xl font-semibold text-center lg:text-left ml-2 lg:ml-20  mt-4 -mb-2">Appointment Booking</h1>
      <div className="bg-white pt-2 text-center lg:text-left">
        <span className="text-red-500 ml-2 lg:ml-20 bg-white">*</span> Required fields
      </div>
      {filled && (
        <div className="text-red-500">
          Your application has been {filled.status}. Comments: {filled.comments}
        </div>
      )}
      <form
        onSubmit={handleSubmit}
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 mx-2 mt-0 pt-8 rounded bg-white lg:px-20"
      >
        <div className="">
          <Input
            color="blue"
            variant="standard"
            label="Name of the Patient: "
            type="text"
            name="patientName"
            value={formData.patientName}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>

        <div className="mb-4">
          <Select
            name="gender"
            color="blue"
            variant="standard"
            label="Gender"
            value={formData.gender}
            onChange={(v)=>handleChange({target:{name: "gender", value:v}})}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          >
            <Option value="male">Male</Option>
            <Option value="female">Female</Option>
            <Option value="other">Other</Option>
            <Option value="choose not to disclose">Other</Option>
          </Select>
        </div>
        <div className="mb-4">
          <Input
            label="Age:"
            type="number"
            variant="standard"
            color="blue"
            name="age"
            value={formData.age}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>
        <div className="mb-4">
          <Input
          label="Address"
            name="address"
            variant="standard"
            color="blue"
            value={formData.address}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>
        <div className="mb-4">
          <Input
            label="Contact Number:"
            type="text"
            variant="standard"
            color="blue"
            name="contactNumber"
            value={formData.contactNumber}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>
        <div className="mb-4">
          <Input
          label="Email:"
          variant="standard"
          color="blue"
            type="text"
            name="email"
            value={formData.email}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>
        <div className="mb-4">
          <Select
            label="Specialiaty of Doctor:"
            variant="standard"
            color="blue"
            type="text"
            name="doctorSpeaciality"
            value={formData.doctorSpeaciality}
            onChange={(v)=>handleChange({target:{name: "doctorSpeaciality", value:v}})}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          >
            <Option value="Cardiologist">Cardiologist</Option>
            <Option value="Nuerologist">Nuerologist</Option>
            <Option value="Pulmonologist">Pulmonologist</Option>
            <Option value="Oncologist">Oncologist</Option>
            <Option value="General Physician">General Physician</Option>
            <Option value="Gynaecologist">Gynaecologist</Option>
            <Option value="ENT">ENT</Option>
            <Option value="Dermatologist">Dermatologist</Option>

          </Select>
        </div>
        
        <div className="mb-4">
          <Input
          label="Doctor Name"
          color="blue"
          variant="standard"
            type="text"
            name="doctorName"
            value={formData.doctorName}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>
        <div className="mb-4">
          <Input
          label="Hospital"
          color="blue"
          variant="standard"
            type="text"
            name="hospital"
            value={formData.hospital}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>
        <div className="mb-4">
          <Input
            color="blue"
            variant="standard"
            label="Appointment Date:"
            type="date"
            name="appointmentDate"
            value={formData.appointmentDate}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>
        <div className="mb-4">
          <Input
            color="blue"
            variant="standard"
            label="Appointment Time:"
            type="text"
            name="appointmentTime"
            value={formData.appointmentTime}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>
        <div className="mb-4">
          <div className="text-xs text-gray-600 mb-1">Copy of Citizenship Proof (pdf):<span className="text-red-500 ml-1 bg-white">*</span></div>
          <input
            
            color="blue"
            variant="standard"
            type="file"
            name="itizenshipProof"
            accept=".pdf"
            ref={file1Ref}
            onChange={(e) => handleFileChange(e, 1)}
            aria-required="true"
            className="text-sm text-stone-500 pb-8 mt-2 file:mr-5 file:py-1 file:px-3 file:border-[1px] file:text-xs file:font-medium file:bg-stone-50 file:text-stone-700 hover:file:cursor-pointer hover:file:bg-blue-50 hover:file:text-blue-700"
            style={{ color: "#000" }}
            required={filled && filled.comments ? false : true}
          />
        </div>
      </form>
      <div className="ml-2 mr-2 md:mx-20">
        <div
          className="text-sm text-gray-500 mt-4 mb-4"
          style={{ color: "#000" }}
        >
          *Booking charges is Rs 50/- which is non-refundable in case of cancelation
        </div>
        {/* Scrollable box for terms and conditions */}
        <h2 className="text-lg font-bold mb-2">Terms and Conditions:</h2>
        <div className="bg-gray-100 rounded-md max-h-48 overflow-y-auto border border-black p-2">
          <p>
            1. The patient would have to abide by the rules of the hospital the doctor practices at.
          </p>
          <p>
            2. The fees of the doctor need to be paid to the hospital at its help desk.
          </p>
          <p>
            3. 10% discount coupon on booking via our website will be given to all users at the help desk.
          </p>
          <p>
            4. Cancelling the appointment anytime before has non-refundable booking charges
          </p>
          <p>
            5. The waiting time can exceed by 10-15 minutes at max in case of some emergency. In such a case an immediate new doctor's appointment in the nearest proximity will be provided by us.
          </p>
          <p>
            6. Children below the age of 18 need to be accompanied by a guardian.
          </p>
          <p>7. Pets/Dogs/Cats etc. are not allowed in the hospital premises.</p>
        </div>

        {/* Checkbox for accepting terms and conditions */}
        <div className="mt-4 flex items-center">
          <input
            type="checkbox"
            id="termsCheckbox"
            name="termsAccepted"
            checked={formData.termsAccepted}
            onChange={handleCheckboxChange}
            className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
          />
          <label
            htmlFor="termsCheckbox"
            className="ml-2 block text-sm text-gray-900"
          >
            I agree to the terms and conditions
          </label>
        </div>

        {/* Submit button */}
        <div className="mt-8 my-10 flex justify-center">
          <button
            type="submit"
            className="bg-color text-white px-6 py-2 rounded-lg w-80 hover:bg-blue-700 focus:outline-none focus:shadow-outline-blue active:bg-blue-800 mb-4"
            onClick={handleSubmit}
          >
            Submit
          </button>
        </div>
      </div>
    </div>
  );
};

export default Form;
