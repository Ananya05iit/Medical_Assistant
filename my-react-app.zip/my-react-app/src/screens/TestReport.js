import React, { useState } from 'react';
import { useAuth } from '../authContext';
import cardiology from '../images/cardiology.jpg';
import oncology from '../images/oncology.jpg';
import pulmonologist from '../images/pulmonologist.jpg';
import "../styles/tailwind.css";

function TestReport(){
    const { currentUser, loading } = useAuth();
    const backendUrl = process.env.REACT_APP_BASE_URL;
    const facilities = [
        { name: 'Analyse Heart Report', imageUrl: cardiology, url: '/heartCheck' },
        { name: 'Analyse Lungs X-ray', imageUrl: pulmonologist, url: '/applicationView' },
        { name: 'Analyse Cancer Reports', imageUrl: oncology, url: '/form' }
    ];
    const [modalIsOpen, setModalIsOpen] = useState(false);
    const [deleteModalIsOpen, setDeleteModalIsOpen] = useState(false);
    const [selectedCirculars, setSelectedCirculars] = useState([]);
    return (
        <div className='text-center flex flex-col '>
          <div className='w-full flex mt-4'>
            <div className='w-7/10 p-4'>
              <h2 className='text-lg font-bold mb-2 bg-black text-white p-2'>Analyse Test Reports</h2>
              <div className='grid grid-cols-3 gap-4'>
      {facilities.map((facility, index) => (
        <div key={index} className='relative shadow-lg p-4 aspect-w-16 aspect-h-9'>
          <img src={facility.imageUrl} alt={facility.name} className='w-full h-full object-cover rounded shadow-lg' />
          <a
            href={facility.url}
            target="_blank"
            rel="noopener noreferrer"
            className='absolute inset-0 flex items-center justify-center w-full h-full bg-black bg-opacity-50 text-white text-center text-2xl no-underline hover:underline rounded'
          >
            {facility.name}
          </a>
        </div>
      ))}
    </div>
      </div>
      </div>
      </div>
      );
}

export default TestReport;


