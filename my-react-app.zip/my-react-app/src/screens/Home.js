import axios from 'axios';
import React, { useEffect, useRef, useState } from 'react';
import Cal from '../Components/Calendar';
import ImageSlider from '../Components/ImageSlider';
import { useAuth } from '../authContext';
import AppointmentStatus from '../images/AppointmentStatus.png';
import bookAppointment from '../images/bookAppointment.jpg';
import feedback from '../images/feedback.jpg';
import healthInsurance from '../images/healthInsurance.jpg';
import mlhealthdiagonsis from '../images/mlhealthdiagonsis.jpg';
import pharmacy from '../images/pharmacy.jpg';

import '../styles/tailwind.css';



function Home() {
  const { currentUser, loading } = useAuth();
  const backendUrl = process.env.REACT_APP_BASE_URL;
  const facilities = [
    { name: 'ML Health Diagonsis', imageUrl: mlhealthdiagonsis, url: '/health1' },
    { name: 'Virtual & Home Care', imageUrl: bookAppointment, url: '/applicationView' },
    { name: 'Book Appointment', imageUrl: AppointmentStatus, url: '/form' },
    { name: 'Give Feedback', imageUrl: feedback, url: '/feedback' },
    { name: 'Purchase Medicines', imageUrl: pharmacy, url: 'https://drone-delivery-vbcc.onrender.com' },
    { name: 'Health Insurance', imageUrl: healthInsurance, url: '/internship' },
  ];
  const facilities2 = [
    { name: 'Emergency', imageUrl: healthInsurance, url: '/emergency' },
  ];
  
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [newCircular, setNewCircular] = useState({ text: '', url: '' });
  const [deleteModalIsOpen, setDeleteModalIsOpen] = useState(false);
  const [selectedCirculars, setSelectedCirculars] = useState([]);

  //working perfectly fine
  const [circulars, setCirculars] = useState([]);
  useEffect(() => {
    axios
      .get(`${backendUrl}/api/circulars`, { withCredentials: true })
      .then((res) => {
        // console.log("here:", res.data);
        setCirculars(res.data);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  }, []);

  const scrollRef = useRef();


  const handleCircularSelect = (id) => {
    setCirculars(circulars.map(circular => {
      if (circular.id === id) {
        return { ...circular, isSelected: !circular.isSelected };
      } else {
        return circular;
      }
    }));
  };

  const deleteSelectedCirculars = async () => {
    const selectedIds = circulars.filter(circular => circular.isSelected).map(circular => circular.id);

    axios.delete(`${backendUrl}/api/circulars`, { data: { ids: selectedIds } }, { withCredentials: true })
      .then((res) => {
        setCirculars(circulars.filter(circular => !circular.isSelected));
        setDeleteModalIsOpen(false);
      })
      .catch((error) => {
        console.error('Failed to delete circulars:', error);
      });
  };

  const handleDelete = (event) => {
    event.preventDefault();
    deleteSelectedCirculars();
  };



  const handleSubmit = (event) => {
    // setModalIsOpen(false);
    event.preventDefault();
    axios.post(`${backendUrl}/api/circulars`, newCircular, { withCredentials: true })
      .then((res) => {
        setCirculars(res.data);
        setModalIsOpen(false);
      })
      .catch((error) => {
        console.error("Error adding circular:", error);
      });
  };

  return (
    <div className='text-center flex flex-col '>
      <div className='w-full'>
        <ImageSlider />
      </div>

      <div className='w-full flex mt-4'>
        <div className='w-7/10 p-4'>
          <h2 className='text-lg font-bold mb-2 bg-black text-white p-2'>Medical Facilities</h2>
          <div className='grid grid-cols-3 gap-4'>
          {facilities.map((facility, index) => (
            <div key={index} className='relative shadow-lg p-4 aspect-w-16 aspect-h-9'>
              <img src={facility.imageUrl} alt={facility.name} className='w-full h-full object-cover rounded shadow-lg' />
              <a
                href={facility.url}
                target="_blank"
                rel="noopener noreferrer"
                className='absolute inset-0 flex items-center justify-center w-full h-full bg-black bg-opacity-50 text-white text-center text-2xl no-underline hover:underline rounded'
              >
                {facility.name}
              </a>
            </div>
          ))}
         {facilities2.map((facility, index) => (
            <div key={index} className='relative shadow-lg p-4 aspect-w-16 aspect-h-9'>
              <img src={facility.imageUrl} alt={facility.name} className='w-full h-full object-cover rounded shadow-lg' style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
              <a
                href={facility.url}
                target="_blank"
                rel="noopener noreferrer"
                className='absolute inset-0 flex items-center justify-center w-full h-full bg-black bg-opacity-50 text-white text-center text-2xl no-underline hover:underline rounded'
              >
                {facility.name}
              </a>
            </div>
            
          ))}
          
      </div>

  <div className='w-full p-4 ml-64'>
    <Cal />
  </div>
  </div>
  </div>
  </div>
  );
}

export default Home;
