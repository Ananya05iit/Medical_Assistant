import { Input, Option, Select } from "@material-tailwind/react";
import axios from "axios";
import React, { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../authContext";
import "../styles/tailwind.css";
const HeartCheck = () => {
  const backendUrl = process.env.REACT_APP_BASE_URL;
  const [commentDiv, setCommentDiv] = useState(false);
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const { filled } = location.state || {};
  const [formData, setFormData] = useState({
    age: "",
    gender: "",
    cp: "",
    trestbps: "",
    chol: "",
    fbs: "",
    restecg: "",
    thalach: "",
    exang: "",
    oldpeak: "",
    slope: "",
    ca: "",
    thal: "",
  });
  const [file1Data, setFile1Data] = useState(null);
  const file1Ref = useRef(null);
  const [file2Data, setFile2Data] = useState(null);
  const file2Ref = useRef(null);
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
    // console.log(e.target.name, e.target.value);
  };
  

  const handleCheckboxChange = () => {
    setFormData({
      ...formData,
      termsAccepted: !formData.termsAccepted,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.termsAccepted) {
      alert("Please accept the terms and conditions");
      return;
    }
    // console.log("Form submitted:", formData);
    
    const data = new FormData();
    data.append("age", formData.age);
    data.append("gender", formData.gender);
    data.append("cp", formData.cp);
    data.append("trestbps", formData.trestbps);
    data.append("chol", formData.chol);
    data.append("fbs", formData.fbs);
    data.append("restecg", formData.restecg);
    data.append("thalach", formData.thalach);
    data.append("exang", formData.exang);
    data.append("oldpeak", formData.oldpeak);
    data.append("slope", formData.slope);
    data.append("ca", formData.ca);
    data.append("thal", formData.thal);
    if (filled) {
      data.append("correction", filled.application_id);
    }
    axios
      .post(
        `${backendUrl}/api/booking`,
        data,
        { withCredentials: true },
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      )
      .then((res) => {
        console.log(res);
        alert("Form Submitted Successfully");
        navigate("/home");
      })
      .catch((err) => {
        console.log(err);
      });
  };
  useEffect(() => {
    if (currentUser) {
      setFormData((prevFormData) => ({
        ...prevFormData,
        patientNameName: currentUser.name,
        email: currentUser.email,
        // Update other fields accordingly
      }));
    }
    if (filled && filled.comments) {
      setCommentDiv(true);
      console.log("Comments:", filled.comments);
    }
  }, [currentUser, filled]);
  return (
    <div className="bg-white px-4 -mt-6 pt-6">
      <h1 className="text-2xl font-semibold text-center lg:text-left ml-2 lg:ml-20  mt-4 -mb-2">Heart Checkup</h1>
      <h1 className="text-2xl font-semibold text-center lg:text-left ml-2 lg:ml-20  mt-4 -mb-2">Enter your heart test report details</h1>
      <div className="bg-white pt-2 text-center lg:text-left">
        <span className="text-red-500 ml-2 lg:ml-20 bg-white">*</span> Required fields
      </div>
      {filled && (
        <div className="text-red-500">
          Your application has been {filled.status}. Comments: {filled.comments}
        </div>
      )}
      <form
        onSubmit={handleSubmit}
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 mx-2 mt-0 pt-8 rounded bg-white lg:px-20"
      >
        <div className="">
          <Input
            color="blue"
            variant="standard"
            label="Age: "
            type="number"
            name="age"
            value={formData.age}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>

        <div className="mb-4">
          <Select
            name="gender"
            color="blue"
            variant="standard"
            label="Gender"
            value={formData.gender}
            onChange={(v)=>handleChange({target:{name: "gender", value:v}})}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          >
            <Option value="male">Male</Option>
            <Option value="female">Female</Option>
            <Option value="other">Other</Option>
            <Option value="choose not to disclose">Other</Option>
          </Select>
        </div>
        <div className="mb-4">
          <Input
            label="Chest Pain:"
            type="number"
            variant="standard"
            color="blue"
            name="cp"
            value={formData.cp}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>
        <div className="mb-4">
          <Input
          label="Resting Blood Pressure"
            name="trestbps"
            variant="standard"
            color="blue"
            type="number"
            value={formData.trestbps}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>
        <div className="mb-4">
          <Input
            label="Cholestrol:"
            type="number"
            variant="standard"
            color="blue"
            name="chol"
            value={formData.chol}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>
        <div className="mb-4">
          <Input
          label="Fetal Bovine Serum:"
          variant="standard"
          color="blue"
            type="number"
            name="fbs"
            value={formData.fbs}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>
        <div className="mb-4">
          <Input
            label="Resting EKG results:"
            variant="standard"
            color="blue"
            type="number"
            name="restecg"
            value={formData.restecg}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>
        
        <div className="mb-4">
          <Input
          label="Thalium Stress Result"
          color="blue"
          variant="standard"
            type="number"
            name="thalach"
            value={formData.thalach}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>
        <div className="mb-4">
          <Input
          label="Exercise-induced Angina"
          color="blue"
          variant="standard"
            type="number"
            name="exang"
            value={formData.exang}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>
        <div className="mb-4">
          <Input
            color="blue"
            variant="standard"
            label="Old Peak of exercise-induced ST depression vs. rest:"
            type="number"
            name="oldpeak"
            value={formData.oldpeak}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>
        <div className="mb-4">
          <Input
            color="blue"
            variant="standard"
            label="Slope of the ST segment of peak exercise:"
            type="number"
            name="slope"
            value={formData.slope}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>
        <div className="mb-4">
          <Input
            color="blue"
            variant="standard"
            label="Number of major vessels (0-3) stained by Fluoroscopy:"
            type="number"
            name="ca"
            value={formData.ca}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>
        <div className="mb-4">
          <Input
            color="blue"
            variant="standard"
            label="Thalium Stress Result:"
            type="number"
            name="thal"
            value={formData.thal}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>
      </form>
      <div className="ml-2 mr-2 md:mx-20">
        <div
          className="text-sm text-gray-500 mt-4 mb-4"
          style={{ color: "#000" }}
        >
        </div>
        {/* Scrollable box for terms and conditions */}
        <h2 className="text-lg font-bold mb-2">Terms and Conditions:</h2>
        <div className="bg-gray-100 rounded-md max-h-48 overflow-y-auto border border-black p-2">
          <p>
            1. The answer predicted here is by ML model which has been trained on a huge dataset to avoid errors.
          </p>
          <p>
            2. The patient is requested to verify the results with a medical practitioner if under doubt.
          </p>
        </div>

        {/* Checkbox for accepting terms and conditions */}
        <div className="mt-4 flex items-center">
          <input
            type="checkbox"
            id="termsCheckbox"
            name="termsAccepted"
            checked={formData.termsAccepted}
            onChange={handleCheckboxChange}
            className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
          />
          <label
            htmlFor="termsCheckbox"
            className="ml-2 block text-sm text-gray-900"
          >
            I agree to the terms and conditions
          </label>
        </div>

        {/* Submit button */}
        <div className="mt-8 my-10 flex justify-center">
          <button
            type="submit"
            className="bg-color text-white px-6 py-2 rounded-lg w-80 hover:bg-blue-700 focus:outline-none focus:shadow-outline-blue active:bg-blue-800 mb-4"
            onClick={handleSubmit}
          >
            Submit
          </button>
        </div>
      </div>
    </div>
  );
};

export default HeartCheck;
