import { Input, Option, Select } from "@material-tailwind/react";
import axios from "axios";
import React, { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../authContext";
import "../styles/tailwind.css";
const Feedback = () => {
  const backendUrl = process.env.REACT_APP_BASE_URL;
  const [commentDiv, setCommentDiv] = useState(false);
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const { filled } = location.state || {};
  const [formData, setFormData] = useState({
    patientName: "",
    contactNumber: "",
    email: "",
    doctorSpeaciality: "",
    doctorName: "",
    hospital: "",
    appointmentDate: "",
    score: "",
  });
  const [file1Data, setFile1Data] = useState(null);
  const file1Ref = useRef(null);
  const [file2Data, setFile2Data] = useState(null);
  const file2Ref = useRef(null);
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
    // console.log(e.target.name, e.target.value);
  };
  
  const handleCheckboxChange = () => {
    setFormData({
      ...formData,
      termsAccepted: !formData.termsAccepted,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.termsAccepted) {
      alert("Please accept the terms and conditions");
      return;
    }
    // console.log("Form submitted:", formData);
    if (
      (formData.arrivalDate > formData.departureDate ||
        formData.arrivalDate <= new Date().toISOString().split("T")[0] ||
        formData.departureDate <= new Date().toISOString().split("T")[0]) &&
      !filled
    ) {
      alert("Please enter valid dates");
      return;
    }
    const data = new FormData();
    data.append("patientName", formData.patientName);
    data.append("contactNumber", formData.contactNumber);
    data.append("email", formData.email);
    data.append("doctorSpeaciality", formData.doctorSpeaciality);
    data.append("doctorName", formData.doctorName);
    data.append("hospital", formData.hospital);
    data.append("appointmentDate", formData.appointmentDate);
    data.append("score", formData.score);
    
    if (filled) {
      data.append("correction", filled.application_id);
    }
    axios
      .post(
        `${backendUrl}/api/booking`,
        data,
        { withCredentials: true },
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      )
      .then((res) => {
        console.log(res);
        alert("Form Submitted Successfully");
        navigate("/home");
      })
      .catch((err) => {
        console.log(err);
      });
  };
  useEffect(() => {
    if (currentUser) {
      setFormData((prevFormData) => ({
        ...prevFormData,
        patientNameName: currentUser.name,
        email: currentUser.email,
        // Update other fields accordingly
      }));
    }
    if (filled && filled.comments) {
      setCommentDiv(true);
      console.log("Comments:", filled.comments);
    }
  }, [currentUser, filled]);
  return (
    <div className="bg-white px-4 -mt-6 pt-6">
      <h1 className="text-2xl font-semibold text-center lg:text-left ml-2 lg:ml-20  mt-4 -mb-2">User Feedback</h1>
      <h2 className="text-2xl font-semibold text-center lg:text-left ml-2 lg:ml-20  mt-4 -mb-2">It matters the most to us !</h2>
      <div className="bg-white pt-2 text-center lg:text-left">
        <span className="text-red-500 ml-2 lg:ml-20 bg-white">*</span> Required fields
      </div>
      {filled && (
        <div className="text-red-500">
          Your application has been {filled.status}. Comments: {filled.comments}
        </div>
      )}
      <form
        onSubmit={handleSubmit}
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 mx-2 mt-0 pt-8 rounded bg-white lg:px-20"
      >
        <div className="">
          <Input
            color="blue"
            variant="standard"
            label="Name of the Patient: "
            type="text"
            name="patientName"
            value={formData.patientName}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>

        <div className="mb-4">
          <Input
            label="Contact Number:"
            type="text"
            variant="standard"
            color="blue"
            name="contactNumber"
            value={formData.contactNumber}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>
        <div className="mb-4">
          <Input
          label="Email:"
          variant="standard"
          color="blue"
            type="text"
            name="email"
            value={formData.email}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>
        <div className="mb-4">
          <Select
            label="Specialiaty of Doctor:"
            variant="standard"
            color="blue"
            type="text"
            name="doctorSpeaciality"
            value={formData.doctorSpeaciality}
            onChange={(v)=>handleChange({target:{name: "doctorSpeaciality", value:v}})}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          >
            <Option value="Cardiologist">Cardiologist</Option>
            <Option value="Nuerologist">Nuerologist</Option>
            <Option value="Pulmonologist">Pulmonologist</Option>
            <Option value="Oncologist">Oncologist</Option>
            <Option value="General Physician">General Physician</Option>
            <Option value="Gynaecologist">Gynaecologist</Option>
            <Option value="ENT">ENT</Option>
            <Option value="Dermatologist">Dermatologist</Option>

          </Select>
        </div>
        
        <div className="mb-4">
          <Input
          label="Doctor Name"
          color="blue"
          variant="standard"
            type="text"
            name="doctorName"
            value={formData.doctorName}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>
        <div className="mb-4">
          <Input
          label="Hospital"
          color="blue"
          variant="standard"
            type="text"
            name="hospital"
            value={formData.hospital}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>
        <div className="mb-4">
          <Input
            color="blue"
            variant="standard"
            label="Appointment Date:"
            type="date"
            name="appointmentDate"
            value={formData.appointmentDate}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>
        <div className="mb-4">
          <Input
            color="blue"
            variant="standard"
            label="Score:"
            type="number"
            name="appointmentDate"
            value={formData.score}
            onChange={handleChange}
            aria-required="true"
            required={filled && filled.comments ? false : true}
          />
        </div>
        
        
      </form>
      
      <div className="ml-2 mr-2 md:mx-20">

        {/* Submit button */}
        <div className="mt-8 my-10 flex justify-center">
          <button
            type="submit"
            className="bg-color text-white px-6 py-2 rounded-lg w-80 hover:bg-blue-700 focus:outline-none focus:shadow-outline-blue active:bg-blue-800 mb-4"
            onClick={handleSubmit}
          >
            Submit
          </button>
        </div>
      </div>
    </div>

  );
};

export default Feedback;
