import {
  Accordion,
  AccordionBody,
  AccordionHeader,
} from "@material-tailwind/react";
import React from "react";
 
export default function DefaultAccordion() {
  const [open, setOpen] = React.useState(1);
 
  const handleOpen = (value) => setOpen(open === value ? 0 : value);
 
  return (
    <div className="mx-4 mb-80 mt-4 lg:mb-20">
      <Accordion open={open === 1} >
        <AccordionHeader onClick={() => handleOpen(1)}>Welcome Note</AccordionHeader>
        <AccordionBody>
        Machine learning is transforming the healthcare industry, enabling more accurate diagnoses, personalized treatments, and improved patient outcomes. I believe,  ML, and AI have the scope to develop models that can analyze vast amounts of data to predict patient outcomes, identify high-risk individuals, and optimize treatment strategies. By leveraging patient data and genomic information, machine learning enables the development of tailored treatment plans for individual patients. It can help automate administrative tasks and streamline clinical workflows, which can help healthcare providers focus more on patient care.

        </AccordionBody>
      </Accordion>
      <Accordion open={open === 2}>
        <AccordionHeader onClick={() => handleOpen(2)}>
          Our Mission
        </AccordionHeader>
        <AccordionBody>
        I am doing this for people who don't get timely information about the disease they are suffering from. Using my website, they can get a fair idea of it. I am also doing it for the Army at the border which succumbs to death due to lack of quick help. So, I want to develop this instant AI doctor who can suggest the best possible treatment by analyzing the symptoms of the soldier. This can also be used for emergency services in areas like trains, metros or planes where getting immediate help is not possible.
        </AccordionBody>
      </Accordion>
      <Accordion open={open === 3}>
        <AccordionHeader onClick={() => handleOpen(3)}>
          Contact Us
        </AccordionHeader>
        <AccordionBody> 
        Feel free to explore our website for more information about our facilities and services.
        If you have any questions or inquiries, don't hesitate to contact us.
        </AccordionBody>
      </Accordion>
    </div>
  );
}