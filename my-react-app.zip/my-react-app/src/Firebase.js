// firebase.js
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore'; // Import getFirestore for Firestore
import { getAnalytics } from "firebase/analytics";

const firebaseConfig = {
    apiKey: "AIzaSyAXoHJYjLh8RiEI8D54lAygi8BeMZ44170",
    authDomain: "ggh123-46201.firebaseapp.com",
    projectId: "ggh123-46201",
    storageBucket: "ggh123-46201.appspot.com",
    messagingSenderId: "435954835551",
    appId: "1:435954835551:web:3ebc55d2b01df45ed6fbea",
    measurementId: "G-SFZKN2SLDL"
  };


const firebaseApp = initializeApp(firebaseConfig);
const auth = getAuth(firebaseApp);
const db = getFirestore(firebaseApp); // Initialize Firestore and getFirestore
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
export { auth, db };
