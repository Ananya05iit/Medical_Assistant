import { Carousel } from "@material-tailwind/react";

export default function Slider() {
  return (
    <div className="pt-3 mx-auto max-w-screen-2xl">
      <div className="slider-container"></div>
        <Carousel loop={true} autoplay={true} className="rounded-xl slider">
          <img
            src="https://techstartups.com/wp-content/uploads/2020/05/US-Doctors.jpg"
            alt="image 1"
            className="h-full w-full object-cover object-center"
          />
          <img
            src="https://theisozone.com/wp-content/uploads/2021/07/AI-In-Healthcare.jpg"
            alt="image 3"
            className="h-full w-full object-cover object-center"
          />
          <img
            src="https://www.nsmedicaldevices.com/wp-content/uploads/sites/2/2021/05/shutterstock_1303927084.png"
            alt="image 5"
            className="h-full w-full object-cover object-center"
          />
          <img
            src="https://i.ytimg.com/vi/aKDkKBZZnTs/maxresdefault.jpg"
            alt="image 4"
            className="h-full w-full object-cover object-center"
          />
        </Carousel>
      <style jsx>{`
        @media (min-width: 768px) {
          .slider {
            height: 600px; /* Set the desired height for desktop */
          }
        }
      `}</style>
    </div>
  );
}
