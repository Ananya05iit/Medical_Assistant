import { ThemeProvider } from "@material-tailwind/react";
import { GoogleOAuthProvider } from '@react-oauth/google';
import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import AuthProvider from './authContext';
import './index.css';
const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(
  <React.StrictMode>
    <AuthProvider>
    <GoogleOAuthProvider clientId="787953873966-u63cbtb21qgopt9b4ekddh1vhvnbm9q7.apps.googleusercontent.com">
    <BrowserRouter>
    <ThemeProvider>
      <App />
    </ThemeProvider>
    </BrowserRouter>
    </GoogleOAuthProvider>
    </AuthProvider>
 </React.StrictMode> 
);
