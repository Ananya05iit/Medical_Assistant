// Imports
//import "bootstrap/dist/css/bootstrap.min.css";
import { useState } from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import { useAuth } from "./authContext";

// Screens and Components
import AboutUs from "./screens/AboutUs";
import Home from "./screens/Home";
import Login from "./screens/Login";
// import Headers from "./components/Headers";
import Footer from "./Components/Footer";
import Headers from "./Components/Headers";
import Contact from "./screens/Contact";
//import Emergency from "./screens/Emergency";
import Emergency from "./screens/Emergency";
import Feedback from "./screens/Feedback";
import Form from "./screens/Form";
import Health1 from "./screens/Health1";
import HeartCheck from "./screens/HeartCheck";
import SignUp from "./screens/Signup";
import TestReport from "./screens/TestReport";


// Landing Page
function LandingPage(){
  const { currentUser, loading } = useAuth();
  const [redirectTo, setRedirectTo] = useState(null);
  
  if (redirectTo) return <Navigate to={redirectTo} />;
  return <div>Loading...</div>;
}


function App() {
  const {currentUser, loading}=useAuth();
  const [showPopup, setShowPopup] = useState(false);
  if(loading)
    return <div>Loading...</div>
  return (
    <section
      className="bg-Hero bg-cover
    font-[Poppins] md:bg-top bg-center p-0 m-0"
    >
      <Headers showPopup={showPopup} setShowPopup={setShowPopup} />
      <Routes>
        <Route path="/" element={<Home />}/>
        <Route path="/home" element={<Home />} />
        <Route path="/heartCheck" element={<HeartCheck />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/form" element={<Form />} />
        <Route path="/feedback" element={<Feedback />} />
        <Route path="/health1" element={<Health1 />} />
        <Route path="/testReport" element={<TestReport />} />
        <Route path="/about" element={<AboutUs />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/emergency" element={<Emergency />} />
        

      </Routes>
      <Footer showPopup={showPopup} setShowPopup={setShowPopup} />
    </section>
  );
}

export default App;
